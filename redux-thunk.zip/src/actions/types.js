export const GET_POSTS = "GET_POSTS";
export const GET_POST = "GET_POST";
export const CREATE_POST = "CREATE_POST";
export const UPDATE_POST = "UPDATE_POST";
export const DELETE_POST = "DELETE_POST";

export const GET_HEALTH = "GET_HEALTH";
export const GET_PATIENT = "GET_PATIENT";
export const CREATE_PATIENT = "CREATE_PATIENT";


