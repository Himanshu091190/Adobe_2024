import React from "react";
import ReactDOM from "react-dom";
import "./styles/index.scss";
import App from "./App";
import MyTestComp from './MyTestComponent';

ReactDOM.render(
  <React.StrictMode>
    <App />
    {/* <MyTestComp /> */}
  </React.StrictMode>,
  document.getElementById("root")
);
