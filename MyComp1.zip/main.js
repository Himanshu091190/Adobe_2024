import React from 'react';
import ReactDOM from 'react-dom';
import App from './App.js';
import LiveData from './LiveData.js';
import { BrowserRouter } from 'react-router-dom';
import CarPrice from './CarPrice.js';

ReactDOM.render((
    <BrowserRouter>
		{/* <App /> */}
    {/* <LiveData /> */}
    <CarPrice/>
        
    </BrowserRouter>
), document.getElementById('app'));