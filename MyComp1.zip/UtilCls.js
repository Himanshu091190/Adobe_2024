export class UtilCls{
    static MyRoot(n) {
        return Math.sqrt(n);
    }

    static MyPow(n){
        return Math.pow(n,2);
    }

    static MyCub(n){
        return Math.pow(n,3);
    }
}

export default UtilCls;