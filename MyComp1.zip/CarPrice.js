import React, { Component } from 'react';
import { Link, Route, Switch } from 'react-router-dom';
import { MyComp1 } from './MyComp1';
import { MyComp2 } from './MyComp2';
import { MyComp3 } from './MyComp3';

class CarPrice extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            carprice: 0,
            roadtax:0,
            servicetax: 0,
            citytax:0,
            totalcost:0
        }
        this.onChange = this.onChange.bind(this);
    }
    onChange(e) {
        this.setState({ carprice: parseInt(e.target.value) });
        this.setState({ roadtax: (e.target.value) * 0.2 });
        this.setState({ servicetax: (e.target.value) * 0.18 });
        this.setState({ citytax: (e.target.value) * 0.1 });
        // var total = ;
    }

    render() {
        return (
            <div>
                <table className="table table-striped">
                    <tr><td>Enter Car Price</td><td><input type="text" onChange={this.onChange} /></td></tr>
                    <br />
                    <tr><td>Base Price</td><td>{this.state.carprice}</td></tr>
                    <tr><td>Road Tax</td><td>{this.state.roadtax}</td></tr>
                    <tr><td>Service Tax</td><td>{this.state.servicetax}</td></tr>
                    <tr><td>City Charge</td><td>{this.state.citytax}</td></tr>
                    <tr><td>Total Cost</td><td>{this.state.carprice+this.state.roadtax+this.state.servicetax+this.state.citytax}</td></tr>

                </table>
            </div>
        );
    }
}


export default CarPrice;