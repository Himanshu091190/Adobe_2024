function sum ( a , b ) {
    // return a + b;
    return parseInt(a,10) + parseInt(b,10);
}

export default sum;