import { makeStyles } from "@material-ui/core";

const styles = makeStyles({});

export default styles;
