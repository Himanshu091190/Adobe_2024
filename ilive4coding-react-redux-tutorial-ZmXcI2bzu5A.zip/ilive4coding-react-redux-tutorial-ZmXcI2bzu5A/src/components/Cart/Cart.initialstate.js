const cartInitialState = {
  products: [],
  show_products: false,
};
export default cartInitialState;
