class Product {
  constructor(id, name, imageUrl, price) {
    this.id = id;
    this.name = name;
    this.imageUrl = imageUrl;
    this.price = price;
  }
}

export default Product;
